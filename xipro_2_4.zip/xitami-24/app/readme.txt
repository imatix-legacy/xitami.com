Xitami/Pro Readme File


 This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit (http://www.openssl.org/).
 This product includes cryptographic software written by Eric Young (eay@cryptsoft.com).
 This product includes software written by Tim Hudson (tjh@cryptsoft.com).

 
This document contains information that has not yet been included in the
Xitami documentation.

Installing Xitami/Pro

    You do not need to have installed Xitami previously to install
    Xitami/Pro.  Xitami/Pro is a superset of the standard Xitami package,
    excluding the 'testcgi' executable.

    Xitami/Pro is supplied as a compressed zip file.  Unzip this into a
    directory of your choice, but not into the principal Xitami directory.

    If you previously installed Xitami, copy the webpages and ftproot
    directory, as well as any custom configuration files.  You can also
    change the defaults.cfg to point to these two locations:

    [Server]
        webpages=xxxx   #  Location of Xitami webpages
    [Ftp]
        root=xxxx       #  Location of Xitami ftproot

    Read the "ssldoc.txt" file which contains instructions about creating
    and using certificates.

    Edit the "sslhttp.cfs" file to tell Xitami/Pro which certificates you
    use.

Upgrading Xitami/Pro

    Before upgrading from a previous version, save the entire Xitami/Pro
    directory.  This is important: any certificates you have created or
    purchased must be saved and restored after upgrading.

    Follow these steps:

    1.  Save the entire Xitami/Pro directory, e.g. using zip:

        zip -r xipro *

    2.  Save the existing sslhttp.cfs file:

        rename sslhttp.cfs sslhttp.cfx
        
    3.  Unzip the new Xitami/Pro installation.

    4.  Restore your old certificates:

        unzip -o xipro *.pem

    5.  Compare sslhttp.cfs and sslhttp.cfx, and update sslhttp.cfs as
        necessary.

SSL Virtual Hosting

Normal HTTP Virtual Hosting works in two ways:

  - using separate IP addresses for each virtual host (multihoming)
  - using the HTTP/1.1 Virtual Host protocol (DNS-based)

The SSL protocol cannot work with HTTP/1.1 Virtual Hosts, so to use SSL
virtual hosts you must have a unique IP address for each host.  This is a
limitation that applies equally to other protocol, e.g. FTP.


#! perl
print "Content-Type: text/html\n\n";
print "<HTML><BODY><H1>Hello</H1></BODY></HTML>";
exit (1);

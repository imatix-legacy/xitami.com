The Xitami Webserver...  Simply Faster!
----------------------------------------------------------------------------

You want SPEED?

    Xitami outperforms other webservers by 2-to-1, or even better.
    It uses a single-process multithreaded design to handle HUNDREDS of
    simultaneous hits with no effort at all.

You want it CLEAN?

    Xitami installs and runs in seconds, with no configuration at all.
    The Windows executable file is just 400Kb with NO DLLs.

You want ROCK-SOLID industrial-strength STABILITY?

    Xitami will run for years without maintenance.  We use a special
    memory management library to detect and flush-out memory leaks.

You want PORTABILITY?

    Xitami will run on Windows 3.x, Windows 95, NT 3.51, NT 4.x, OS/2,
    all possible UNIX systems, and Digital OpenVMS.

You want FEATURES?

    Virtual hosts, CGI, image maps, standard logging, password protection,
    aliases, Perl/Awk/Rexx support, easy install/uninstall, log cycling,
    dynamic reconfiguration, user-defined MIME types, on-line admin,...

You want it for FREE?

    Xitami is totally free and comes with sources.  Technical support is
    free for the first ten thousand users... :)

You want it NOW?

    Go to http://www.imatix.com/ and download the latest version.


YOU GOT IT.

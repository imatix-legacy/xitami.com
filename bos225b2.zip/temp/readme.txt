This file holds temporary files used for CGI i/o.  You can change the
location Xitami uses by modifying the CGI workdir option; for instance to
use an environment variable like $(TEMP).

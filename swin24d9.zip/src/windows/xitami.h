/*  ----------------------------------------------------------------<Prolog>-
    Name:       xitami.h
    Title:      XITAMI Web Server for Windows
    Package:    Libero SMT 2.x

    Written:    96/11/15  iMatix Corporation
    Revised:    99/05/16

    Synopsis:   Common definitions for the Windows control panels.

    Copyright:  Copyright (c) 1991-98 iMatix Corporation
    This program is copyright (c) 1991-1997.  Its usage and distribution are
    subject to the terms of a iMatix Software Licence Agreement.
 ------------------------------------------------------------------</Prolog>-*/

#ifndef _XITAMI_INCLUDED
#define _XITAMI_INCLUDED

#include "sfl.h"                        /*  SFL library header file          */
#include "smtlib.h"                     /*  SMT kernel functions             */
#include "smtdefn.h"                    /*  SMT agent definitions            */
#include "smthttpl.h"                   /*  SMTHTTP definitions              */

/*- Global definitions ------------------------------------------------------*/

#define SERVER_NAME  "Xitami web server v" CUR_VERSION " (c) 1991-99 iMatix"
#define SERVER_VERS  "Xitami v" CUR_VERSION
#define APPLICATION  "Xitami"
#define SETUP_NOTE   \
    "About to enter the browser-based setup screens...  If this does not "  \
    "work, run your browser and connect to 'http://127.0.0.1/admin'. The "  \
    "setup screens are protected by a password defined in xitami.aut or  "  \
    "defaults.aut.  If Windows says that it cannot find URL.DLL, please  "  \
    "install the TCP/IP networking component of Windows.  Now click Ok!"

#define QUOTES_TEXT                                                         \
    "NOTICE: this program is Open Source Software; please read the file "   \
    "LICENSE.TXT for conditions of use and distribution.  Xitami is "       \
    "provided in the hope that it will be useful, but without warranty, "   \
    "not even the implied warranty of merchantability or fitness for a "    \
    "particular purpose."


/*- Global variables --------------------------------------------------------*/

static char
    string [LINE_MAX + 1];              /*  Variable for resource strings    */


/*- Function prototypes -----------------------------------------------------*/

int xiadmin_init (void);                /*  Xitami administration agent      */
int xierror_init (void);                /*  Xitami error simulation agent    */
int xixlog_init  (void);                /*  Xitami extended logging agent    */
int xixssi_init  (void);                /*  Xitami SSI agent                 */
int xilrwp_init (void);                 /*  Xitami LRWP agent                */


#endif

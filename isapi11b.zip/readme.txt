                     ISAPI <-> Xitami LRWP bridge Daemon
     Written by the Xitami Team at iMatix Corporation <xitami@imatix.com>

The ISAPI module runs as a Xitami LRWP plugin.  To run this you need Xitami
with LRWP 1.0 or 2.0 enabled.  Start Xitami first, and then start isapid
with appropriate parameters.  A ISAPI test module is provided as testisapi.dll.

There are two modes that the ISAPI daemon can be used in:

1.  Like CGI, you have a executable directory or alias (default is 
    scripts in PWS) and all file in this directory are ISAPI applications:

    To do this, after starting Xitami, you run: 

    isapid -app isapi_exe 

    and URL is:

    http://localhost/isapi_exe/testisapi.dll?query=this_value

    For more details you can see PWS/IIS help for ISAPI.  The ISAPI 
    bridge daemon is compatible with this approach.

2.  You process all file with specific extension, like "pl" for perl or 
    "php" for PHP scripts.   Here you specify the extension to use, and a 
    DLL to be used for processing the extension.

    For example for perl, after starting Xitami, you run:

    isapid -app .pl -dll c:\perl\bin\perlis.dll

    and the URL is:

    http://localhost/sub_dir/my_app.pl

    And for PHP, after starting Xitami, you run:

    isapid -app .php -dll e:\php\php4isapi.dll ....

    and the URL is:

    http://localhost/sub_dir/my_app.php

The startup parameters for isapid are:

Usage: isapid [option...]
Options:
  -trace             Set trace mode on (trace request in log file)
  -host  host_name   Set LRWP Host value (default value is 127.0.0.1)
  -port  port_value  Set LRWP Port value (default value is 81)
  -app   name:       Set application name (default value is 'scripts')
  -dll   dll_name    Set DLL value if application is a extension
  -vhost host_name   Set virtual host to apply
  -log   file_name   Log file name in trace mode (default value is isapid.log)
  -u                 Unload DLL after each client request
  -h                 Display this message

isapid is Open Source software.  You can modify it and redistribute it as
described in the file LICENSE.TXT.  The source code is provided in the
src subdirectory.

/*  ----------------------------------------------------------------<Prolog>-
    Name:       isapid.c
    Title:      ISAPI Bridge LRWP Daemon
    Package:    Xitami

    Written:    1999/02/25  Pascal Antonnaux <pascal@imatix.com>
    Revised:    2000/01/03

    Copyright:  Copyright (c) 1991-99 iMatix Corporation
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SMT License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#include "sfl.h"                        /*  SFL header file                  */
#include "lrwplib.h"                    /*  LRWP library header file         */
#include <httpext.h>                    /*  ISAPI structure definitions      */

/*- Definition --------------------------------------------------------------*/

#define APPLICATION_NAME    "ISAPID"
#define APPLICATION_VERSION "1.1b"

/* Define default value                                                      */
#define DEFAULT_NAME        "scripts"
#define DEFAULT_HOST        "127.0.0.1"
#define DEFAULT_PORT        "81"
#define DEFAULT_LOG         "isapid.log"

#define ISAPI_ERROR_PAGE                                                     \
    "<html><header><title>Isapi extension error</title></header>\n"          \
    "<Body><H2>Xitami ISAPI extension error</H2><HR><I>%s</I></body></html>"

#define USAGE                                                                \
    "Usage: " APPLICATION_NAME "[option...]\n"                               \
    "Options:\n"                                                             \
    "  -trace            Set trace mode on (trace request in log file)\n"    \
    "  -host  host_name  Set Host value (default value is 127.0.0.1)\n"      \
    "  -port  port_value Set Port value (default value is 81)\n"             \
    "  -app   name:      Set application name (default value is 'scripts')\n"\
    "  -dll   dll_name   Set DLL value if application is a extension\n"      \
    "  -vhost host_name  Set virtual host to apply\n"                        \
    "  -log   file_name  Log file name in trace mode (default value is '"    \
    DEFAULT_LOG "')\n"                                                       \
    "  -u                Unload DLL after each client request\n"             \
    "  -h                Display this message\n"


#define TIME_OUT_PENDING    10000          /* Set time-out for pending       *
                                            * thread to 10 sec               */

/* The mandatory exports from the ISAPI DLL                                  */
 
typedef BOOL  (WINAPI * ISAPI_VERSION)   (HSE_VERSION_INFO *); 
typedef DWORD (WINAPI * ISAPI_MAIN)      (EXTENSION_CONTROL_BLOCK *); 
typedef BOOL  (WINAPI * ISAPI_TERMINATE) (DWORD);


typedef struct                          /* ISAPI CONTEXT structure           */
{
    char 
        dll_name [256];                 /*   DLL File name                   */
    HINSTANCE
        dll_handle;                     /*   DLL handle                      */
    ISAPI_VERSION
        version;                        /*   Version function                */
    ISAPI_MAIN
        main;                           /*   Main function                   */
    ISAPI_TERMINATE
        terminate;                      /*   Terminate function              */
    HSE_VERSION_INFO
        version_info;                   /*   Version info structure          */
    EXTENSION_CONTROL_BLOCK 
        ecb;                            /*   Control block for ISAPI         */

} ISAPI_CTX;

/* Extra definition for ISAPI 4.0                                            */

#if HSE_VERSION_MAJOR < 4

/* HTTP status code and header                                               */
typedef struct _HSE_SEND_HEADER_EX_INFO  
{
    LPCSTR  pszStatus;                  /* HTTP status code  eg: "200 OK"    */
    LPCSTR  pszHeader;                  /* HTTP header                       */

    DWORD   cchStatus;                  /* number of characters in status    */
    DWORD   cchHeader;                  /* number of characters in header    */

    BOOL    fKeepConn;                  /* keep client connection alive?     */

}  HSE_SEND_HEADER_EX_INFO,
  *LPHSE_SEND_HEADER_EX_INFO;

#define   HSE_REQ_SEND_RESPONSE_HEADER_EX          (HSE_REQ_END_RESERVED+16)

#endif

/*- Macro definition --------------------------------------------------------*/

/* Set CGI value macro                                                       */

#define SET_CGI_VALUE(name, buffer)                                          \
{                                                                            \
    SYMBOL *symbol = NULL;                                                   \
    symbol = sym_lookup_symbol (lrwp.cgi, name);                             \
    buffer = symbol? symbol-> value: empty_value;                                     \
}

/*- Global Variables --------------------------------------------------------*/

static LRWP
    lrwp;                               /* LRWP global structure             */
static int
    error_code;                         /* LRWP error code value             */
char
    *application = NULL,                /* Application name                  */
    *dll_name    = NULL,                /* Dll name                          */
    *host        = NULL,                /* Host name or IP value             */
    *port        = NULL,                /* Port value                        */
    *vhost       = NULL,                /* Virtual host                      */
    *log_name    = NULL;                /* Log file name (in trace mode)     */
static Bool
    extension_mode = FALSE,             /* Indicate extension mode           */
    trace_mode     = FALSE;             /* Indicate trace mode ON/OFF        */
SYMTAB
    *dll_cache;                         /* Symbol table with DLL context     */
Bool
    alway_unload = FALSE,               /* Indicate if dll unloaded after    *
                                         * each request                      */
    session_done;                       /* Indicate if session is done       */
char
    *empty_value = "";

/*- Local function prototype ------------------------------------------------*/

Bool        decode_parameter        (int        arg_c, char *arg_v []);
void        handle_signal           (int        the_signal);
BOOL        fill_context            (ISAPI_CTX *isapi_ctx); 
void        unload_dll              (ISAPI_CTX *ctx);
void        remove_from_cache       (ISAPI_CTX *ctx);
void        set_html_error_page     (char      *error);
ISAPI_CTX  *get_isapi_ctx           (void);
ISAPI_CTX  *load_dll                (void);
char       *get_dll_file_name       (void);
void        free_all_resources      (void);
void        move_to_directory       (void);

/*- ISAPI callback function prototype ---------------------------------------*/

BOOL WINAPI get_server_variable     (HCONN, LPSTR,  LPVOID,  LPDWORD); 
BOOL WINAPI read_client             (HCONN, LPVOID, LPDWORD); 
BOOL WINAPI write_client            (HCONN, LPVOID, LPDWORD, DWORD); 
BOOL WINAPI server_support_function (HCONN, DWORD,  LPVOID,  LPDWORD, LPDWORD); 

/*----------------------------- M A I N -------------------------------------*/
void
main(int argc, char* argv[])
{
    char
        *error_message = NULL;          /* LRWP message value                */
    ISAPI_CTX 
        *ctx;                           /* ISAPI context                     */ 
    DWORD
        return_msg;                     /* Return code from main ISAPI func. */
    long
        time_out;                       /* Time out value for status pending */

    if (!decode_parameter (argc, argv))
      {
        puts (USAGE);
        exit(1);
      }

    /* Set trace mode settings                                               */
    if (trace_mode)
      {
        enable_trace ();
        set_trace_file (log_name, 'a');
      }

    signal (SIGINT,  handle_signal);
    signal (SIGSEGV, handle_signal);
    signal (SIGTERM, handle_signal);

    sock_init ();
    console_set_mode (CONSOLE_DATETIME);
    memset (&lrwp, 0, sizeof (LRWP));

    /* Connect to HTTP server                                                */
    error_message = lrwp_connect (&lrwp, application, host, port, vhost);
    if (error_message)
      {
        coprintf ("%s\n", error_message);
        free_all_resources ();
        exit(1);
      }

    dll_cache = sym_create_table ();

    coprintf ("%s %s: waiting for '%s' on %s:%s",
               APPLICATION_NAME, APPLICATION_VERSION,
               application, host, port);

    /* Preload DLL if in extension mode and move the current directory       */
    if (extension_mode)
      {
         move_to_directory ();
         get_isapi_ctx ();
      } 
    /* Main loop                                                             */
    while (lrwp_accept_request (&lrwp) != -1)
      {
        /* Get ISAPI context (load DLL if needed)                            */
        ctx = get_isapi_ctx ();
        if (ctx)
          {
            /* Fill context with current value                               */
            fill_context (ctx);

            /* Execute main routine of ISAPI extension                       */
            session_done = FALSE;
            __try
              {
                return_msg = ctx-> main ((EXTENSION_CONTROL_BLOCK *)&ctx-> ecb);
              }
            /* Send fatal error message if a error occur                     */
            __except (EXCEPTION_EXECUTE_HANDLER)
              {
                set_html_error_page ("Fatal Error in ISAPI extension");
                coprintf ("Error: Fatal Error in ISAPI extension %s\n",
                                 ctx-> dll_name);
                remove_from_cache (ctx);
                ctx = NULL;
              }

            /* If ISAPI extension return STATUS PENDING, wait 10 sec         */
            if (return_msg == HSE_STATUS_PENDING)
              {
                time_out = TIME_OUT_PENDING;/* Set time out value to 10 sec  */
                do
                  {
                    Sleep (200);        /* Wait 200 mSec                     */
                    if (session_done == TRUE)
                        break;
                    time_out -= 200;
                  } while (time_out > 0);
                if (time_out <= 0)
                    coprintf ("Error: time-out with pending thread\n");
              }
          }

        /* End of request                                                    */
        if (lrwp.size > 0)
            error_code = lrwp_finish_request (&lrwp);
        else
            lrwp_cleanup(&lrwp);
  
        if (alway_unload)
          {
            remove_from_cache (ctx);
            ctx = NULL;
          }
      }

    free_all_resources ();
}

/*###########################################################################*/
/*#                             Local function                              #*/
/*###########################################################################*/

/*  ---------------------------------------------------------------------[<]-
    Function: decode_parameter

    Synopsis: Decode all parameter and set global value.
    ---------------------------------------------------------------------[>]-*/

Bool
decode_parameter (int arg_c, char *arg_v [])
{
    int
        argn;                           /*  Argument number                  */
    Bool
        args_ok = TRUE;                 /*  Were the arguments okay?         */
    char
        **argparm;                      /*  Argument parameter to pick-up    */

    argparm = NULL;
    for (argn = 1; argn < arg_c; argn++)
      {
        /*  If argparm is set, we have to collect an argument parameter      */
        if (argparm)
          {
            if (*arg_v [argn] != '-')    /*  Parameter can't start with '-'  */
              {
                *argparm = mem_strdup (arg_v [argn]);
                argparm = NULL;
              }
            else
              {
                args_ok = FALSE;
                break;
              }
          }
        else
        if (*arg_v [argn] == '-')
          {
            switch (arg_v [argn][1])
              {
                /*  These switches take a parameter                          */
                case 'H':
                case 'h':
                    /* Check if help needed                                  */
                    if (arg_v [argn][2] != 'o'
                    &&  arg_v [argn][2] != '0')
                      {
                        puts (USAGE);
                        exit (EXIT_SUCCESS);
                      }
                    else                /* Host value                        */
                        argparm = &host;
                    break;
                case 'p':               /* Port value                        */
                case 'P':
                    argparm = &port;        break;
                case 'a':               /* Application value                 */
                case 'A':
                    argparm = &application; break;
                case 'd':               /* DLL value                         */
                case 'D':
                    argparm = &dll_name;    break;
                case 'v':               /* Virtual host value                */
                case 'V':
                    argparm = &vhost;       break;
                case 't':               /* Trace mode on                     */
                case 'T':
                    trace_mode = TRUE;      break;
                case 'L':               /* Trace file name                   */
                case 'l':
                    argparm = &log_name;    break;
                case 'U':               /* Alway unload ON                   */
                case 'u':
                    alway_unload = TRUE;    break;
                /*  Anything else is an error                                */
                default:
                    args_ok = FALSE;
              }
          }
        else
          {
            args_ok = FALSE;
            break;
          }
      }

    /* Set default value                                                     */
    if (args_ok)
      {
        if (application == NULL)
            application = mem_strdup (DEFAULT_NAME);
        if (host        == NULL)
            host        = mem_strdup (DEFAULT_HOST);
        if (port        == NULL)
            port        = mem_strdup (DEFAULT_PORT);
        if (log_name    == NULL)
            log_name    = mem_strdup (DEFAULT_LOG);
        if (*application == '.')
            extension_mode = TRUE;

        if (extension_mode && dll_name == NULL)
          {
            coprintf ("Error: missing DLL name for this extension");
            args_ok = FALSE;
          }
      }
    return (args_ok);
}

/*  ---------------------------------------------------------------------[<]-
    Function: free_all_resources

    Synopsis: Free all resource allocated by application
    ---------------------------------------------------------------------[>]-*/

void
free_all_resources (void)
{
    static Bool
        first_time = TRUE;              /* Indicate the first free resource  */
    SYMBOL
        *symbol;

    if (first_time)
      {
        first_time = FALSE;

        if (trace_mode)
            trace ("Free all resource");


        /* Free global variable                                              */

        if (application)
            mem_strfree (&application);
        if (dll_name)
            mem_strfree (&dll_name);
        if (host)
            mem_strfree (&host);
        if (port)
            mem_strfree (&port);
        if (vhost)
            mem_strfree (&vhost);
        if (log_name)
            mem_strfree (&log_name);

        /* Free the cache and unload all DLL                                 */
        if (dll_cache)
          {
            for (symbol = dll_cache-> symbols; symbol; symbol = symbol-> next)
                unload_dll ((ISAPI_CTX *)symbol-> data);
            sym_delete_table (dll_cache);
            dll_cache = NULL;
          }

        /* Close LRWP connection                                             */
        if (lrwp.sock)
          {
            error_code = lrwp_close (&lrwp);
            sock_term ();
            lrwp.sock = 0;
          }

        mem_assert ();
      }
}


/*  ---------------------------------------------------------------------[<]-
    Function: handle_signal

    Synopsis: Handle signal of end.
    ---------------------------------------------------------------------[>]-*/

void
handle_signal (int the_signal)
{
    if (trace_mode)
        trace ("handle signal %d", the_signal);

    free_all_resources ();
    exit (EXIT_FAILURE);
}


/*  ---------------------------------------------------------------------[<]-
    Function: move_to_directory

    Synopsis: Get directory off dll_name and set the current directory of
              this process to this directory.
    ---------------------------------------------------------------------[>]-*/

void
move_to_directory (void)
{
    char
        *cur_dir,
        *end;

    if (dll_name == NULL)
        return;

    cur_dir = mem_strdup (dll_name);
    if (cur_dir)
      {
        end = strrchr (cur_dir, '\\');
        if (end)
          {
            *end = '\0';
            if (strused (cur_dir))
              {
                if (trace_mode)
                    trace ("Set current directory to %s", cur_dir);
                set_curdir (cur_dir);
              }
          }
        mem_free (cur_dir);
      }
}


/*  ---------------------------------------------------------------------[<]-
    Function: get_isapi_ctx

    Synopsis: Search a ISAPI_CTX in cache. If not found, create context.
    ---------------------------------------------------------------------[>]-*/

ISAPI_CTX  *
get_isapi_ctx (void)
{
    ISAPI_CTX
        *ctx = NULL;                    /* ISAPI context pointer             */
    char
        *dll_name;                      /* DLL file name                     */
    SYMBOL
        *symbol;

    dll_name = get_dll_file_name ();

    if (trace_mode)
        trace ("Get isapi ctx for %s", dll_name);

    symbol = sym_lookup_symbol (dll_cache, dll_name);

    /* If DLL is not loaded                                                  */
    if (symbol == NULL)
      {
        ctx = load_dll ();
        if (ctx)
          {
            symbol = sym_create_symbol (dll_cache, dll_name, "");
            if (symbol)
              {
                symbol-> data = ctx;
                coprintf ("%s: load dll '%s'",
                          APPLICATION_NAME, ctx-> dll_name);
              }
          }
      }
    else
        ctx = (ISAPI_CTX *)symbol-> data;

    return (ctx);
}

/*  ---------------------------------------------------------------------[<]-
    Function: fill_context

    Synopsis: Fill the ISAPI ECB block with function pointer and Variable value.
    ---------------------------------------------------------------------[>]-*/

BOOL
fill_context (ISAPI_CTX *isapi_ctx)
{
    EXTENSION_CONTROL_BLOCK 
        *ecb;                           /* Control block for ISAPI           */

    ASSERT  (isapi_ctx);

    ecb = &isapi_ctx-> ecb;

    /* Pointers to the functions the DLL will call.                          */
     
    ecb-> GetServerVariable     = get_server_variable; 
    ecb-> ReadClient            = read_client; 
    ecb-> WriteClient           = write_client; 
    ecb-> ServerSupportFunction = server_support_function; 
 
    /* Fill in the standard CGI environment variables                        */
     
    SET_CGI_VALUE ("REQUEST_METHOD",  ecb-> lpszMethod);
    SET_CGI_VALUE ("QUERY_STRING",    ecb-> lpszQueryString);
    SET_CGI_VALUE ("PATH_INFO",       ecb-> lpszPathInfo);
    SET_CGI_VALUE ("PATH_TRANSLATED", ecb-> lpszPathTranslated);
    SET_CGI_VALUE ("CONTENT_TYPE",    ecb-> lpszContentType);
    ecb-> cbTotalBytes = sym_get_number (lrwp.cgi, "CONTENT_LENGTH", 0);
    ecb-> cbAvailable  = strlen(lrwp.post_data);
    ecb-> lpbData      = lrwp.post_data; 

    if (trace_mode)
      {
        trace ("Fill context:");
        trace ("    Method:          %s",   ecb-> lpszMethod);
        trace ("    Query string:    %s",   ecb-> lpszQueryString);
        trace ("    Path info:       %s",   ecb-> lpszPathInfo);
        trace ("    Path translated: %s",   ecb-> lpszPathTranslated);
        trace ("    Content type:    %s",   ecb-> lpszContentType);
        trace ("    Content length:  %d",   ecb-> cbTotalBytes);
        trace ("    Available:       %d",   ecb-> cbAvailable);
        trace ("    Post data:       %20s", ecb-> lpbData);
      }
    return (TRUE);
}


/*  ---------------------------------------------------------------------[<]-
    Function: get_dll_file_name

    Synopsis: Get the dll file name (use path_info value)
    ---------------------------------------------------------------------[>]-*/

char *
get_dll_file_name (void)
{
    char
        *path_info =NULL;

    if (extension_mode)
        return (dll_name);

    SET_CGI_VALUE ("PATH_INFO", path_info);

    if (*path_info == '/')
        path_info++;

    path_info = strlwc (path_info);

    return (path_info);
}


/*  ---------------------------------------------------------------------[<]-
    Function: load_dll

    Synopsis: Load DLL module and retrieve external function address.
    ---------------------------------------------------------------------[>]-*/

ISAPI_CTX  *
load_dll (void)
{
    ISAPI_CTX
        *ctx = NULL;                    /* ISAPI context pointer             */
    char
        temp_buffer [256],              /* Working buffer                    */
        *module_name;                   /* DLL file name                     */

    /* Allocate ISAPI context                                                */
    ctx = mem_alloc (sizeof (ISAPI_CTX));
    if (ctx == NULL)
        return (NULL);
    memset (ctx, 0, sizeof (ISAPI_CTX));

    ctx-> ecb.cbSize    = sizeof   (EXTENSION_CONTROL_BLOCK); 
    ctx-> ecb.dwVersion = MAKELONG (HSE_VERSION_MINOR, HSE_VERSION_MAJOR); 
    ctx-> ecb.ConnID    = 0; 

    /* Get DLL file name                                                     */
    module_name = get_dll_file_name ();
    if (module_name)
        strcpy (ctx-> dll_name, module_name);
    else
      {
        sprintf (temp_buffer, "Error: failure to get DLL name\n");

        set_html_error_page (temp_buffer);
        coprintf ("%s", temp_buffer);

        mem_free (ctx);
        return (NULL);
      }
    
    if (trace_mode)
        trace ("Loading DLL %s", ctx-> dll_name);

    /* Load DLL                                                              */
    ctx-> dll_handle = LoadLibrary (ctx-> dll_name);
 
    if (!ctx-> dll_handle)
      { 
        sprintf (temp_buffer, "Error on load %s (%d)\n",
                        ctx-> dll_name, GetLastError ()); 

        set_html_error_page (temp_buffer);
        coprintf ("%s", temp_buffer);

        mem_free (ctx);
        return (NULL); 
      } 

    /* Find the exported functions                                           */
 
    ctx-> version = (ISAPI_VERSION)GetProcAddress (ctx-> dll_handle,  
                                                   "GetExtensionVersion"); 
    if (!ctx-> version)
      { 
        sprintf(temp_buffer, "Error: Can't Get ISAPI Version function (%d)\n",
                             GetLastError ()); 

        set_html_error_page (temp_buffer);
        coprintf ("%s", temp_buffer);

        FreeLibrary (ctx-> dll_handle);
        mem_free (ctx);
        return (NULL); 
      } 
    ctx-> main = (ISAPI_MAIN)GetProcAddress (ctx-> dll_handle,  
                                             "HttpExtensionProc"); 
    if (!ctx-> main)
      { 
        sprintf (temp_buffer,
                 "Error: Can't Get ISAPI Extension Proc function (%d)\n",
                 GetLastError ()); 

        set_html_error_page (temp_buffer);
        coprintf ("%s", temp_buffer);

        FreeLibrary (ctx-> dll_handle);
        mem_free (ctx);
        return (NULL); 
      }

    ctx-> terminate = (ISAPI_TERMINATE)GetProcAddress (ctx-> dll_handle,  
                                                       "TerminateExtension"); 

    /* This should really check if the version information matches what      *
     * we expect.                                                            */
 
    __try 
     { 
        if (!ctx-> version(&ctx-> version_info))
          { 
            sprintf (temp_buffer,
            "Error: Execution of ISAPI GetExtensionVersion function failed\n"); 

            set_html_error_page (temp_buffer);
            coprintf ("%s", temp_buffer);

            FreeLibrary (ctx-> dll_handle);
            mem_free (ctx);
            return (NULL); 
          } 
        else
        if (trace_mode)
          {
            trace ("%s (Ext version %d.%d)",
                   ctx-> version_info.lpszExtensionDesc,
                   HIWORD (ctx-> version_info.dwExtensionVersion), 
                   LOWORD (ctx-> version_info.dwExtensionVersion));
          }
     } 
    __except(1)
     { 
        FreeLibrary (ctx-> dll_handle);
        mem_free (ctx);
        return (NULL); 
     } 
    return (ctx);
}


/*  ---------------------------------------------------------------------[<]-
    Function: unload_dll

    Synopsis: Unload DLL and free ISAPI context
    ---------------------------------------------------------------------[>]-*/

void
unload_dll (ISAPI_CTX *ctx)
{

    ASSERT (ctx);

    if (trace_mode)
        trace ("Unload DLL %s", ctx-> dll_name);

    /* Call termination function                                             */
    __try
      {
        if (ctx-> terminate)
            ctx-> terminate (HSE_TERM_MUST_UNLOAD);
      }
    /* Send fatal error message if a error occur                     */
    __except (EXCEPTION_EXECUTE_HANDLER)
      {
          set_html_error_page ("Fatal Error in ISAPI extension");
          coprintf ("Error: Fatal Error on ISAPI extension unload %s\n",
                                 ctx-> dll_name);
      }


    if (ctx-> dll_handle)
        FreeLibrary (ctx-> dll_handle);

    mem_free (ctx);
}


/*  ---------------------------------------------------------------------[<]-
    Function: set_html_error_page

    Synopsis: Send a html page with error
    ---------------------------------------------------------------------[>]-*/

void
set_html_error_page (char *error)
{
    static char
        buffer [1024];                  /* Working buffer                    */

    sprintf (buffer, ISAPI_ERROR_PAGE, error);
    lrwp_send_string (&lrwp, buffer);
}


/*  ---------------------------------------------------------------------[<]-
    Function: remove_from_cache

    Synopsis: Remove a ISAPI context from the cache.
    ---------------------------------------------------------------------[>]-*/

void
remove_from_cache (ISAPI_CTX *ctx)
{
    SYMBOL
          *symbol;

    ASSERT (ctx);

    if (dll_cache)
      {
        symbol = sym_lookup_symbol (dll_cache, ctx-> dll_name);
        if (symbol)
          {
            unload_dll (ctx);
            sym_delete_symbol (dll_cache, symbol);
          }
      }
}

/*###########################################################################*/
/*#                         ISAPI CallBack functions                        #*/
/*###########################################################################*/

/*  ---------------------------------------------------------------------[<]-
    Function: get_server_variable

    Synopsis: ISAPI callback function to retrieve cgi environment variable
    ---------------------------------------------------------------------[>]-*/

BOOL WINAPI 
get_server_variable (HCONN  conn_handle, LPSTR   variable_name, 
                     LPVOID buffer,      LPDWORD size) 
{
    char
        *out,
        *colon,
        *end,
        **all_value,                    /* All Text values                   */ 
        *value = NULL;                  /* Variable value                    */
    int
        len,
        index;
    BOOL
        feedback = FALSE;

    if (lexcmp (variable_name, "ALL_HTTP") == 0)
      {
        all_value = symb2strt (lrwp.cgi);
        if (all_value)
          {
            out = (char *)buffer;
            end = out + *size;
            for (index = 0; all_value [index]; index++)
              {
                if (lexncmp (all_value [index], "HTTP_", 5) == 0)
                  {
                    len = strlen (all_value [index]);
                    if (out + len + 2 < end)
                      {
                        colon = strchr (all_value [index], '=');
                        if (colon)
                            *colon = ':';
                        strcpy (out, all_value [index]);
                        out += len; 
                        *out++ = '\r';
                        *out++ = '\n';
                      }
                  }
              }
            *out = '\0';
            strtfree (all_value);
            if (trace_mode)
                trace ("Get server variable: %s = %40s", variable_name, buffer);
            feedback = TRUE;
          }
      }
    else
      {
        value = sym_get_value (lrwp.cgi, variable_name, NULL);
        if (value 
        &&  buffer 
        &&  strlen (value) < (size_t)*size)
          {
            strcpy (buffer, value);

            if (trace_mode)
                trace ("Get server variable: %s = %40s", variable_name, buffer);
            feedback = TRUE;           
          }
      }
    return (feedback);
}


/*  ---------------------------------------------------------------------[<]-
    Function: read_client

    Synopsis: ISAPI callback function to read data from client.
    ---------------------------------------------------------------------[>]-*/

BOOL WINAPI
read_client (HCONN conn_handle, LPVOID buffer, LPDWORD size)
{
    DWORD
        data_size;

    if (trace_mode)
        trace ("Read client");

    /* Set size to read                                                      */
    data_size = (lrwp.post_size > *size)? *size - 1: lrwp.post_size;

    memcpy (buffer, lrwp.post_data, data_size);

    *((char *)buffer + data_size) = '\0';

    return (TRUE);
}


/*  ---------------------------------------------------------------------[<]-
    Function: write_client

    Synopsis: ISAPI callback function for write to client.
    ---------------------------------------------------------------------[>]-*/

BOOL WINAPI 
write_client (HCONN conn_handle, LPVOID buffer, LPDWORD size, 
    DWORD dwReserved)
{
    lrwp_send_data (&lrwp, buffer, (size_t)*size);

    if (trace_mode)
        trace ("Write to client %ld bytes", *size);

    return (TRUE);
}


/*  ---------------------------------------------------------------------[<]-
    Function: server_support_function

    Synopsis: ISAPI callback function to execute some support functions.

    Supported function:

    HSE_REQ_SEND_RESPONSE_HEADER
    HSE_REQ_SEND_RESPONSE_HEADER_EX
    HSE_REQ_DONE_WITH_SESSION
    HSE_REQ_SEND_URL_REDIRECT_RESP
    ---------------------------------------------------------------------[>]-*/

BOOL WINAPI 
server_support_function (HCONN conn_handle, DWORD HSE_request, LPVOID buffer,
                         LPDWORD size, LPDWORD data_type)
{
    BOOL
        feedback = FALSE;               /* Feedback value                    */
    LPHSE_SEND_HEADER_EX_INFO 
        header;                         /* Extended header structure         */
    char
        temp_buffer [1024];             /* Working buffer                    */
    int
        length;                         /* Buffer length value               */

    if (trace_mode)
        trace ("server support function: request %ld", HSE_request);

    switch (HSE_request)
      { 
        case HSE_REQ_SEND_RESPONSE_HEADER: 
            if (buffer
            &&  size
            &&  *size > 0)
              {
                sprintf (temp_buffer, "Status: %s\r\n", buffer);
                lrwp_send_string (&lrwp, temp_buffer);

                if (trace_mode)
                    trace ("    Status: %s", buffer);
                feedback = TRUE;
              }
            break; 

        /* Implementation of extended header of ISAPI 4.0                    */
        case HSE_REQ_SEND_RESPONSE_HEADER_EX:
            if (buffer)
              {
                temp_buffer [0] = '\0';
                length = 0;

                header = (LPHSE_SEND_HEADER_EX_INFO)buffer;
                if (header-> cchStatus  > 0
                &&  header-> pszStatus != NULL)
                  {
                    sprintf (temp_buffer, "Status: %s\r\n", header-> pszStatus);
                    length += (int)header-> cchStatus + 10;

                    if (trace_mode)
                        trace ("    status: %s", header-> pszStatus);
                  }
                if (header-> cchHeader  > 0
                &&  header-> pszHeader != NULL)
                  {
                    sprintf (&temp_buffer [length], "%s",
                                                    header-> pszHeader);
                    length += (int)header-> cchHeader;

                    if (trace_mode)
                        trace ("    %s", header-> pszHeader);
                  }
                if (length > 0)
                    lrwp_send_data (&lrwp, temp_buffer, length);

                feedback = TRUE;
              }
            break;

        /* Signal end of extension in pending status                         */
        case HSE_REQ_DONE_WITH_SESSION: 
            session_done = TRUE;
            feedback = TRUE;
            break; 
 
        case HSE_REQ_SEND_URL_REDIRECT_RESP: 
            if (buffer
            &&  size
            &&  *size > 0)
              {
                sprintf (temp_buffer,
                         "Status: 302 Moved Temporarily\r\nLocation: %s\r\n",
                         buffer);
                lrwp_send_string (&lrwp, temp_buffer);

                if (trace_mode)
                    trace ("    302 redirect to %s", buffer);
                feedback = TRUE;
              }
            break; 
      } 

    return (feedback);
}


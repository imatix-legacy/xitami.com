readme.txt - Read Me file 

Copyright (c) 1991-2003 iMatix Corporation

This is the Xitami Open project, the Open Source installation of
Xitami.

Xitami is the iMatix web server, built on top of iMatix's RealiBase
toolset.  Xitami is provided under the GNU General Public License
(GPL) for free software developers, and the iMatix General Terms of
Business for commercial developers.

Xitami is maintained by iMatix Corporation.  For more information
please see http://www.imatix.com/ and http://www.xitami.com.

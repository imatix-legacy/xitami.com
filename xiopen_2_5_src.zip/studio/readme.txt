readme.txt - Read Me file 

Copyright (c) 1991-2003 iMatix Corporation

Studio is iMatix Corporation's technical platform for small, fast, portable
web applications.

Studio is part of the iMatix Xitami product.  Xitami is provided under
the GNU General Public License (GPL) for free software developers, and the
iMatix General Terms of Business for commercial developers.

Xitami is maintained by iMatix Corporation.  For more information please
see http://www.imatix.com/ and http://www.xitami.com/.

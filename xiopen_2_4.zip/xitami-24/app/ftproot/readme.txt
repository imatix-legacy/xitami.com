FTP root directory

    - User directories are generally created below this directory
    - Each user directory can be specified with a leading path to point
      to some other specific location
    - The ftp root directory is defined by the [Ftp]root option.

The example ftpusers.aut file uses the 'pub', 'upload', and 'guest'
directories defined here.

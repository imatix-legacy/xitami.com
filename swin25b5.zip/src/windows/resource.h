//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Xiwin.rc
//
#define IDS_ERR_REGISTER_CLASS          1
#define IDS_ERR_CREATE_WINDOW           2
#define IDC_IMATIX                      2
#define IDC_EMAIL                       3
#define IDC_XITAMI                      4
#define IDR_MAIN                        101
#define IDC_NOTIFY                      101
#define IDC_DELAY                       102
#define IDB_BITMAP                      103
#define IDC_STOP                        103
#define IDC_SUSPEND                     103
#define IDI_ICON                        104
#define IDC_TERMINATE                   104
#define IDD_MAIN                        105
#define IDD_ABOUT                       106
#define IDD_HTTP                        107
#define IDB_BITMAP1                     111
#define IDR_POPUP_MENU                  112
#define IDI_ICON_ON                     113
#define IDI_ICON_OFF                    115
#define IDB_ON                          121
#define IDB_OFF                         122
#define IDD_MAIN_SERVICE                123
#define IDD_CRASH                       124
#define IDB_BITMAP2                     125
#define IDD_ABOUT_PRO                   125
#define IDB_ACTIVE                      126
#define IDD_PRO_SERVICE                 126
#define IDI_ICON_ACTIVE                 127
#define IDB_BITMAP3                     129
#define IDB_BITMAP4                     130
#define IDC_STARTUP                     1000
#define IDC_SETUP                       1001
#define IDC_ABOUT                       1002
#define IDC_HOSTNAME                    1003
#define IDC_START                       1004
#define IDC_SERVER_STATE                1005
#define IDC_IPADDRESS                   1006
#define IDC_CONNECTIONS                 1007
#define IDC_TRANSFERRED                 1008
#define IDC_ERRORS                      1009
#define IDC_RESET                       1010
#define IDC_MEMORY                      1011
#define IDC_VERSION                     1012
#define IDC_ACTIVEUSERS                 1013
#define IDC_ICON_STATE_ON               1014
#define IDC_ICON_STATE_OFF              1015
#define IDC_ACTIVE_USERS                1019
#define IDC_CUR_CONNECTS                1020
#define IDC_TOTAL_CONNECTS              1021
#define IDC_MAX_CONNECTS                1022
#define IDC_STATE                       1023
#define IDC_HELPS                       1024
#define IDC_STATE_ON                    1028
#define IDC_STATE_OFF                   1029
#define IDC_STATE_ACTIVE                1031
#define IDC_QUOTES                      1032
#define IDC_MESSAGE                     1033
#define IDC_RESTART                     1034
#define IDC_DEBUG                       1035
#define IDC_MAILTO                      1036
#define IDC_COPY                        1036
#define IDC_ABORT                       1037
#define IDC_BUTTON1                     1038
#define IDR_EXIT                        40001
#define IDFM_PROPERTIES                 40002
#define IDM_ACTIVE                      40003
#define IDFM_ACTIVE                     40003
#define IDM_TERMINATE                   40004
#define IDM_ABOUT                       40006
#define IDFM_SETUP                      40007
#define IDFM_TERMINATE                  40008
#define IDFM_ABOUT                      40009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        157
#define _APS_NEXT_COMMAND_VALUE         40010
#define _APS_NEXT_CONTROL_VALUE         1039
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif

/*  ----------------------------------------------------------------<Prolog>-
    Name:       xitami.h
    Title:      XITAMI Web Server for Windows
    Package:    Libero SMT 2.x

    Written:    1996/11/15  iMatix Corporation
    Revised:    2000/05/23

    Synopsis:   Common definitions for the Windows control panels.

    Copyright:  Copyright (c) 1996-2000 iMatix Corporation
 ------------------------------------------------------------------</Prolog>-*/

#ifndef _XITAMI_INCLUDED
#define _XITAMI_INCLUDED

#include "sfl.h"                        /*  SFL library header file          */
#include "smtlib.h"                     /*  SMT kernel functions             */
#include "smtdefn.h"                    /*  SMT agent definitions            */
#include "smthttpl.h"                   /*  SMTHTTP definitions              */

/*- Global definitions ------------------------------------------------------*/

#define SERVER_VERS  "Xitami v" CUR_VERSION
#define APPLICATION  "Xitami"
#define SETUP_NOTE   \
    "About to enter the browser-based setup screens...  If this does not "  \
    "work, run your browser and connect to 'http://127.0.0.1/admin'. The "  \
    "setup screens are protected by a password defined in xitami.aut or  "  \
    "defaults.aut.  If Windows says that it cannot find URL.DLL, please  "  \
    "install the TCP/IP networking component of Windows.  Now click Ok!"

#define QUOTES_TEXT                                                         \
    "NOTICE: this program is Open Source Software; please read the file "   \
    "LICENSE.TXT for conditions of use and distribution.  Xitami is "       \
    "provided in the hope that it will be useful, but without warranty, "   \
    "not even the implied warranty of merchantability or fitness for a "    \
    "particular purpose."


/*- Global variables --------------------------------------------------------*/

static char
    string [LINE_MAX + 1];              /*  Variable for resource strings    */


#endif

****************************** XiFusion v2.5 ********************************

I.  Introduction
II.  Installation
III.  Testing
IV.  What's New
V.  Credits
VI.  Conclusion


I.  Introduction
  XiFusion is a tiny wrapper application for Xitami to make it work properly
with ColdFusion (hence the name XiFusion).  The program is designed to make
it easy to set up ColdFusion to work with the Xitami server.  XiFusion has
been tested with ColdFusion Server Express v4.0, CF Express v4.5, CF
Professional v4.5 (SP2), and CF Enterprise v4.5 (SP2) (w/o ClusterCats).
Further testing will be performed over the next couple months.  XiFusion is
way too cool to keep as part of the Shining Light Productions' Intranet...
so, enjoy!

NOTE:  With v2.0, RedHat Linux v6.2 and compatible OSes are supported.  Look
       for notes like this one throughout the documentation to make the
       Linux installation go easier.

PHP NOTE:  With v2.5, PHP is supported.  Look for PHP notes like this one
           throughout the documentation to make the PHP installation go
           easier.


II.  Installation
  XiFusion installation is a snap.  First install Xitami (preferrably as a
Windows NT service since ColdFusion runs well under NT).  Then install
ColdFusion.  During the installation, Xitami will not be detected (this is to
be expected, hence the need for XiFusion).  At that point continue on even
though the ColdFusion installer complains.  When the main web page directory
dialog comes up, locate your Xitami directory where web pages are stored
(usually C:\Program Files\Xitami\webpages).  Finish the installation of
ColdFusion and reboot.

  When NT (or 95/98) comes back up, locate the ColdFusion binary directory
(usually C:\CFUSION\BIN) and copy XiFusion.exe into that directory.  Now go
to the Xitami directory (usually C:\Program Files\Xitami) and edit the
Xitami.cfg file.  Look for the [Filter] section.  Add a new filter with a
line that looks like the following:

  .cfm=c:\cfusion\bin\XiFusion c:\cfusion\bin\cfml.exe

  Filters are executables that run when the server sees a particular
extension.  The XiFusion executable is tied to the .cfm file.  The text
following XiFusion is an argument that tells XiFusion where the ColdFusion
parser is.  XiFusion wraps cfml.exe with the necessary data to run and then
executes the program.

NOTE:  Path information is different under Linux (you should use absolute
       paths to the destination executables...avoid symlinks and relative
       paths).

PHP NOTE:  The line in the [Filter] section should look like this:
           .php=c:\cfusion\bin\XiFusion c:\php\php.exe

  Now close the Xitami.cfg file and edit defaults.cfg.  Look for the [Server]
section (if one does not exist create one).  It should already look like
this:

[Server]
  Default1=index.html
  Default2=index.htm
  Default3=default.htm

Now add the following line after Default3

  Default4=index.cfm

If Default4 already exists, choose a different number...if two lines have the
same number, the server will probably crash.

NOTE:  Under Linux, this line can be added to either defaults.cfg or
       Xitami.cfg.  It is recommended that new items be added only to
       defaults.cfg.

PHP NOTE:  The line to add for PHP is:
           Default5=index.php


III.  Testing
  This one is easy.  First, before testing the XiFusion wrapper, the Xitami
service needs to be restarted to recognize the changes.  This can be done
from Control Panel->Xitami->Suspend...wait a second...->Start.

NOTE:  Linux obviously doesn't have a Start menu.  Also, Xitami for Linux
       says you can make the changes without restarting, but you have to
       restart Xitami anyway.

  Now locate the ColdFusion group in the Start Menu.  Launch the ColdFusion
Administrator.  If everything worked fine so far (no broken images), enter
the password entered during the installation and click submit.  If the
password is correct and a menu appears at the left, then the ultimate test
has arrived.  (To correct the broken images copy all of the files in the
'c:\Program Files\Xitami\webpages\CFIDE\Administrator\images' directory to
'c:\Program Files\Xitami\webpages\CFIDE\images').

NOTE:  ColdFusion Express v4.5.1 for Linux also has a bad link somewhere.
       Copy the file expressadmin.css from CFIDE/administrator/express/ to
       CFIDE/administrator/.
NOTE:  ColdFusion Professional and Enterprise v4.5 (SP2) for Linux both have
       bad links somewhere.  Copy the file cfadmin.css from
       CFIDE/administrator/server/ to CFIDE/administrator/.

  Click on the 'ODBC' option.  A few datasources should appear.  Click the
'Verify All' button.  If a dialog box pops up saying something about a DLL
not loading, then that means the Access 97 ODBC database drivers haven't been
installed (install Office 97 to correct the problem).  More than likely,
though, the datasources should test just fine (except for the MQIS SQL Server
datasource).  If the Access driver based databases work, then that means
everything should work.

NOTE:  ColdFusion for Linux has its own ODBC drivers and will work with
       Linux's PostGreSQL server as well.


IV.  What's New
Version 2.5:
  Windows 9x:  65,536 bytes (Build #45)
  Windows NT:  65,536 bytes (Build #45)
  RedHat Linux:  9,856 bytes (No build count yet)
  As of this release, XiFusion works successfully with PHP4!
  Fixed a potential header bug in the Linux version.
  Fixed the blank page bug.

Version 2.0:
  Windows 9x:  65,536 bytes (Build #33)
  Windows NT:  65,536 bytes (Build #33)
  RedHat Linux:  9,364 bytes (No build count yet)
  Tested successfully with ColdFusion Professional and Enterprise v4.5 (SP2)!
    Now works with the following combinations:
      Windows - Xitami v2.4d7, XiFusion v2.0, ColdFusion Express v4.0/
                CF Express v4.5 (SP1)/CF Professional v4.5 (SP2)/
                CF Enterprise v4.5 (SP2)
      Linux - Xitami v2.4d7, XiFusion v2.0, ColdFusion Express v4.5 (SP1)/
              CF Professional v4.5 (SP2)/CF Enterprise v4.5 (SP2)
              (CF Express v4.0 for Linux is untested)
  The Windows version now spawns new processes instead of calling the
    system.  This fixes a problem with modifying certain environment
    variables under the Xitami NT Service (v2.4d7) (no problem under 98 or
    Linux).  The Linux version still calls the system and appears to not have
    any problems with the environment.
  The Windows version increased 1,536 bytes from v1.4.
  Fixed a bug with absolute path calculation.
  Fixed a bug with PATH_TRANSLATED.
  Recompiled with optimizations for speed.
  UNIX support!  All RedHat Linux fans (and those with compatible OSes) now
    can use XiFusion and ColdFusion as well!
  Started to track the number of builds.

Version 1.5:
  Short-lived version that was 'missing a DLL'.  I forgot to test the
    program on another machine before distributing it.  It worked fine on my
    own machine.  Oh well, you win most, you lose a couple.

Version 1.4:
  Fixed a multi-threading problem.  Two copies of XiFusion executing at the
    exact same time on the server caused pages to not be returned.
  Fixed a problem with one type of absolute URL.  Version 1.0 supported
    'http://' links, v1.3's relative link handler took away that support.
    The relative link handler now handles all absolute and relative URLs
    properly.

Version 1.3:
  XiFusion is a few kilobytes larger this time since it was re-written
    (64,000 bytes).
  Fixed the <CFLOCATION> tag bug with relative links.  In XiFusion v1.0,
    relative links would cause something to "hang" (probably the web
    browser) and the browser would time out on pages.

Version 1.0:
  Original version


V.  Credits
  Name                                 E-mail Address
-----------------------------------------------------------------------------
  Thomas J. Hruska                     shinelight@crosswinds.net


VI.  Conclusion
  XiFusion brings together the best of both worlds:  Fast and Free.  With the
powerful combination of Xitami, XiFusion, and ColdFusion Express, dynamic web
page design is only a couple tags away!  Enjoy this product because it is
being released as Freeware!  XiFusion is just one more way that Shining Light
Productions is "Meeting the Needs of Fellow Programmers!"

Signed,
Thomas J. Hruska

Shining Light Productions
"Meeting the Needs of Fellow Programmers"
